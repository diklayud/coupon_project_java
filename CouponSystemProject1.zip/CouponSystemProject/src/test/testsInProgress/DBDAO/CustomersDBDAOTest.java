package test.testsInProgress.DBDAO;

import dbDao.CustomersDBDAO;

public class CustomersDBDAOTest {
    public static void main(String[] args) {

        CustomersDBDAO customersDBDAO = new CustomersDBDAO();
      /*  try {

            // TEST ADD CUSTOMERS
//            customersDBDAO.addCustomer(new Customer("cus1", "tomer1", "c1@cust", "c1c1"));
//            customersDBDAO.addCustomer(new Customer("cus2", "tomer2", "c2@cust", "c2c2"));
//            customersDBDAO.addCustomer(new Customer("cus3", "tomer3", "c3@cust", "c3c3"));

            // TEST SEARCH CUSTOMER
//            System.out.println(customersDBDAO.isCustomerExists("c1@cust", "c1c1"));
//            System.out.println(customersDBDAO.isCustomerExists("c2@cust", "c1c1"));

            // TEST GET ALL CUSTOMERS
//            List<Customer> customers = customersDBDAO.getAllCustomers();
//            customers.forEach(System.out::println);

            // TEST GET A SINGLE CUSTOMER
//            Customer customer = customersDBDAO.getOneCustomer(0);
//            System.out.println(customer);
//            Customer customer1 = customersDBDAO.getOneCustomerByID(1);
//            System.out.println(customer1);

            // TEST UPDATE CUSTOMER
//            customer1.setFirstName("1cus1");
//            customer1.setLastName("1tomer1");
//            customer1.setEmail("1c1@1cust1");
//            customer1.setPassword("1c1c1c");
//            customersDBDAO.updateCustomer(customer1);
//            System.out.println(customer1);

            // TEST DELETE CUSTOMER
//            System.out.println(customersDBDAO.deleteCustomer(1));
//            System.out.println(customersDBDAO.getOneCustomerByID(1));

        } //catch (CouponsException throwables) {
         //   throwables.printStackTrace();
        }

       */

    }
}
