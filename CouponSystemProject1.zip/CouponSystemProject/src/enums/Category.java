package enums;

public enum Category {

    Food, Electricity, Restaurant, Vacation, Fashion


}
