package enums;

public enum ClientType {

    Administrator, Company, Customer
}
